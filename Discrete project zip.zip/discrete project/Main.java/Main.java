import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;

// Class to manage sets of strings
class SetOfStrings {
    private Set<String> universe;
    private ArrayList<Set<String>> sets;

    public SetOfStrings(Set<String> universe, ArrayList<Set<String>> sets) {
        this.universe = universe;
        this.sets = sets;
    }

    public Set<String> union(int a, int b) {
        return union(sets.get(a), sets.get(b));
    }

    public Set<String> union(Set<String> a, Set<String> b) {
        Set<String> result = new HashSet<>(a);
        result.addAll(b);
        return result;
    }

    public Set<String> intersect(int a, int b) {
        return intersect(sets.get(a), sets.get(b));
    }

    public Set<String> intersect(Set<String> a, Set<String> b) {
        Set<String> result = new HashSet<>(a);
        result.retainAll(b);
        return result;
    }

    public Set<String> complement(int a) {
        return complement(sets.get(a));
    }

    public Set<String> complement(Set<String> a) {
        Set<String> result = new HashSet<>(universe);
        result.removeAll(a);
        return result;
    }

    public Set<String> difference(int a, int b) {
        return difference(sets.get(a), sets.get(b));
    }

    public Set<String> difference(Set<String> a, Set<String> b) {
        Set<String> result = new HashSet<>(a);
        result.removeAll(b);
        return result;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Set<String> universe = new HashSet<>();
        universe.add("apple");
        universe.add("banana");
        universe.add("cherry");
        universe.add("date");
        universe.add("fig");
        universe.add("grape");

        ArrayList<Set<String>> sets = new ArrayList<>();
        int numberOfSets = 0;

        // Input for number of sets
        while (true) {
            try {
                System.out.println("Enter number of sets you want to create: ");
                numberOfSets = scanner.nextInt();
                if (numberOfSets <= 0) {
                    throw new IllegalArgumentException("Number of sets must be greater than 0.");
                }
                scanner.nextLine(); // Consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        // Input for sets
        for (int i = 0; i < numberOfSets; i++) {
            Set<String> set = new HashSet<>();
            while (true) {
                System.out.println("Enter elements for Set " + (i + 1) + " (comma separated): ");
                String input = scanner.nextLine();
                if (input.trim().isEmpty()) {
                    System.out.println("Set cannot be empty. Please enter at least one element.");
                    continue;
                }
                String[] elements = input.split(",");
                for (String element : elements) {
                    set.add(element.trim());
                }
                sets.add(set);
                break;
            }
        }

        SetOfStrings setOfStrings = new SetOfStrings(universe, sets);
        boolean exit = false;

        // Menu for operations
        while (!exit) {
            System.out.println("\nChoose an operation:");
            System.out.println("1. Union");
            System.out.println("2. Intersection");
            System.out.println("3. Complement");
            System.out.println("4. Difference");
            System.out.println("5. Exit");

            int choice = 0;
            // Input validation for the menu choice
            while (true) {
                try {
                    choice = scanner.nextInt();
                    if (choice < 1 || choice > 5) {
                        throw new IllegalArgumentException("Please choose a valid operation (1-5).");
                    }
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a valid number between 1 and 5.");
                    scanner.nextLine(); // Consume invalid input
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            }

            switch (choice) {
                case 1:
                    // Union
                    int uIndex = getValidSetIndex(scanner, sets.size());
                    int vIndex = getValidSetIndex(scanner, sets.size());
                    System.out.println("Union: " + setOfStrings.union(uIndex, vIndex));
                    printVennDiagram("Union", sets.get(uIndex), sets.get(vIndex));
                    break;
                case 2:
                    // Intersection
                    int iIndex = getValidSetIndex(scanner, sets.size());
                    int jIndex = getValidSetIndex(scanner, sets.size());
                    System.out.println("Intersection: " + setOfStrings.intersect(iIndex, jIndex));
                    printVennDiagram("Intersection", sets.get(iIndex), sets.get(jIndex));
                    break;
                case 3:
                    // Complement
                    int cIndex = getValidSetIndex(scanner, sets.size());
                    System.out.println("Complement: " + setOfStrings.complement(cIndex));
                    printVennDiagram("Complement", sets.get(cIndex), null);
                    break;
                case 4:
                    // Difference
                    int dIndex = getValidSetIndex(scanner, sets.size());
                    int eIndex = getValidSetIndex(scanner, sets.size());
                    System.out.println("Difference: " + setOfStrings.difference(dIndex, eIndex));
                    printVennDiagram("Difference", sets.get(dIndex), sets.get(eIndex));
                    break;
                case 5:
                    // Exit
                    exit = true;
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    // Helper method to validate set index input
    private static int getValidSetIndex(Scanner scanner, int size) {
        int index = -1;
        while (true) {
            try {
                System.out.print("Enter index of set (0 to " + (size - 1) + "): ");
                index = scanner.nextInt();
                if (index < 0 || index >= size) {
                    throw new IllegalArgumentException("Index out of bounds. Please enter a valid index.");
                }
                scanner.nextLine(); // Consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.nextLine(); // Consume invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
        return index;
    }

    // Method to print Venn diagram
    public static void printVennDiagram(String operation, Set<String> setA, Set<String> setB) {
        System.out.println("\n" + operation + " Venn Diagram:");

        switch (operation) {
            case "Union":
                System.out.println("        ___            ___");
                System.out.println("       /       \\          /       \\ ");
                System.out.println("      |    A    |        |    B    |");
                System.out.println("       \\__/          \\__/ ");
                System.out.println("          |                  |         ");
                System.out.println("      (A ∪ B) = " + setA + " U " + setB);
                System.out.println("This represents the combined area of both sets A and B, including their overlap.");
                break;

            case "Intersection":
                System.out.println("        ___            ___");
                System.out.println("       /       \\          /       \\ ");
                System.out.println("      |    A    |        |    B    |");
                System.out.println("       \\__/          \\__/ ");
                System.out.println("          |                  |         ");
                System.out.println("       (A ∩ B) = " + setA.retainAll(setB));
                break;

            case "Complement":
                System.out.println("       ___     ");
                System.out.println("      /       \\    ");
                System.out.println("     |   A'    |   ");
                System.out.println("      \\___/    ");
                System.out.println("     Complement of A = " + setA);
                break;

            case "Difference":
                System.out.println("        ___            ___");
                System.out.println("       /       \\          /       \\ ");
                System.out.println("      |    A    |        |    B    |");
                System.out.println("       \\__/          \\__/ ");
                System.out.println("       (A - B) = " + setA);
                break;
        }
    }
}